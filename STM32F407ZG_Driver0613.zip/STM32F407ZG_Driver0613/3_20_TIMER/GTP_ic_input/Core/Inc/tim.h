/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    tim.h
  * @brief   This file contains all the function prototypes for
  *          the tim.c file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __TIM_H__
#define __TIM_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

extern TIM_HandleTypeDef htim5;

/* USER CODE BEGIN Private defines */
typedef struct {
  uint8_t finish : 1;  // bit7:0,没有成功的捕获;1,成功捕获到一次
  uint8_t state  : 1;  // bit6:0,没有捕获到上升沿;1,已经捕获到上升沿了.
  uint8_t data   : 6;  // bit5~bit0：溢出次数 
} Tim_State;

extern Tim_State g_timxchy_cap_sta;
extern uint16_t g_timxchy_cap_val;
/* USER CODE END Private defines */

void MX_TIM5_Init(void);

/* USER CODE BEGIN Prototypes */

/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __TIM_H__ */

